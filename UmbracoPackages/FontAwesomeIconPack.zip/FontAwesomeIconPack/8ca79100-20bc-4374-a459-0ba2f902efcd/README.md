# FontAwesomeIconPack
Add Font Awesome to your selectable icons in Umbraco
